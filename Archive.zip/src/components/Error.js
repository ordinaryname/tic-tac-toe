import React, { Component } from 'react';

class Error extends Component {

  render() {
    return(
      <div>
        <h1>No such page exists</h1>
      </div>
    );
  }

}

export default Error;
